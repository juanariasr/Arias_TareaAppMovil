# tarjeta_presentacion

Proyecto Flutter escrito en el lenguaje Dart.

Es una tarea para los alumnos del curso de Introducción a la Ingeniería (Ingeniería Civil Informática UTFSM)


